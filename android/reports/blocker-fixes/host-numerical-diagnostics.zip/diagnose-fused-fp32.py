import json
from pathlib import Path
import numpy as np
import onnx
from onnx import numpy_helper

root = Path(__file__).resolve().parents[2]
directory = root / 'android/app/build/model-reference/trace-fused'
report = {'scope': 'diagnostic only: sampled first frozen float32 NHWC convolution',
          'vehicle_tx_enabled': False, 'models': {}}
for name in ('dmonitoring_model', 'driving_supercombo'):
  model = onnx.load(directory / (name + '.onnx'))
  node = next(node for node in model.graph.node if node.op_type == 'NhwcFusedConv')
  weights = {v.name: numpy_helper.to_array(v) for v in model.graph.initializer}
  attrs = {a.name: onnx.helper.get_attribute_value(a) for a in node.attribute}
  with np.load(directory / (name + '-outputs.npz')) as values:
    source, expected = values[node.input[0]], values[node.output[0]]
  kernel, bias = weights[node.input[1]], weights[node.input[2]]
  p, s = attrs['pads'], attrs['strides']
  padded = np.pad(source, ((0,0), (p[0],p[2]), (p[1],p[3]), (0,0)))
  coords = np.random.default_rng(42).integers([0,0,0], expected.shape[1:], size=(256,3))
  expected = np.array([expected[0,y,x,c] for y,x,c in coords])
  x = np.array([padded[0,y*s[0]:y*s[0]+kernel.shape[2],x*s[1]:x*s[1]+kernel.shape[3],:]
                for y,x,c in coords])
  w = kernel[coords[:,2]].transpose(0,2,3,1)
  biases = bias[coords[:,2]]
  entry = report['models'][name] = {'operator': node.name, 'samples': len(coords), 'policies': {}}
  for layout in ('hwc','chw'):
    a,b = (x,w) if layout == 'hwc' else (x.transpose(0,3,1,2),w.transpose(0,3,1,2))
    a,b = a.reshape(len(coords),-1),b.reshape(len(coords),-1)
    for lanes in (1,2,4,8,16):
      for fused in (True,False):
        for bias_first in (True,False):
          acc = np.zeros((len(coords),lanes),np.float32)
          if bias_first: acc[:,0] = biases
          for k in range(a.shape[1]):
            product = a[:,k].astype(np.float64) * b[:,k]
            if not fused: product = product.astype(np.float32)
            acc[:,k%lanes] = acc[:,k%lanes].astype(np.float64) + product
          while acc.shape[1] > 1:
            acc = (acc[:,::2] + acc[:,1::2]).astype(np.float32)
          actual = acc[:,0] if bias_first else acc[:,0] + biases
          if attrs.get('activation') == b'Relu': actual = np.maximum(actual,0)
          error = np.abs(actual.astype(np.float64)-expected)
          label = f'{layout}_{lanes}_lanes_fma{fused}_biasfirst{bias_first}'
          entry['policies'][label] = {'exact': int(np.count_nonzero(actual==expected)),
                                     'max_abs_error': float(error.max()),
                                     'mismatched': int(np.count_nonzero(error > 1e-4 + 1e-3*np.abs(expected)))}
  entry['best'] = sorted(entry['policies'],key=lambda k:(-entry['policies'][k]['exact'],entry['policies'][k]['max_abs_error']))[:5]
output = root/'android/reports/blocker-fixes/fused-convolution-accumulation.json'
output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({name:{key:value for key,value in m.items() if key!='policies'} for name,m in report['models'].items()},indent=2))
