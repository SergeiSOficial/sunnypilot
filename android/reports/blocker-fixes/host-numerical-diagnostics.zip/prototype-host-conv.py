import json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app/src/main/python'))
import numpy as np
import onnx
from onnx import numpy_helper
from tinygrad import Tensor,UOp,dtypes
from tinygrad.dtype import AddrSpace
from tinygrad.uop.ops import AxisType,KernelInfo,Ops
from tinygrad.nn.onnx import OnnxRunner
from tinygrad.helpers import Context
from fold3_opencl import fused_ops

def host_conv(x,w,b=None,residual=None,activation=None,activation_params=(),strides=(1,1),pads=(0,0,0,0),
              dilations=(1,1),group=1,auto_pad='NOTSET',kernel_shape=None,bias_first=True):
  if x.dtype != dtypes.float32 or w.dtype != dtypes.float32 or auto_pad not in ('NOTSET',b'NOTSET'):
    raise ValueError((x.dtype,w.dtype,auto_pad))
  n,ih,iw,ic=x.shape;oc,icg,kh,kw=w.shape
  if ic != icg*group or activation_params: raise ValueError('shape/activation unsupported')
  pt,pl,pb,pr=pads;sh,sw=strides;dh,dw=dilations
  oh=(ih+pt+pb-dh*(kh-1)-1)//sh+1;ow=(iw+pl+pr-dw*(kw-1)-1)//sw+1
  padded=x.pad(((0,0),(pt,pb),(pl,pr),(0,0))).contiguous()
  bias=Tensor.zeros(oc,device=x.device,dtype=x.dtype) if b is None else b
  def accumulate(dest,left,right,bias):
    lane=UOp.range(dest.numel(),0)
    k=UOp.range(icg*kh*kw,1,AxisType.LOOP)
    c=lane%oc;px=lane//oc%ow;py=lane//oc//ow%oh;batch=lane//oc//ow//oh
    ky=k//icg//kw;kx=k//icg%kw;ci=k%icg
    reg=UOp.placeholder((1,),dtypes.float32,0,addrspace=AddrSpace.REG)
    reg=reg.after(lane)[0].set(bias[c].load() if bias_first else 0.)
    a=left[batch,py*sh+ky*dh,px*sw+kx*dw,c//(oc//group)*icg+ci].load()
    b=right[c,ci,ky,kx].load()
    value=UOp(Ops.CUSTOM,src=(a,b,reg.after(k)[0].load()),arg=('fma({0}, {1}, {2})',dtypes.float32))
    reg=reg[0].set(value,end=k)
    return dest.flatten()[lane].set(reg[0],end=lane).sink(arg=KernelInfo(name=f'host_conv_{oc}_{icg}_{kh}_{kw}',opts_to_apply=()))
  value=Tensor.empty(n,oh,ow,oc,device=x.device,dtype=x.dtype).custom_kernel(padded,w,bias,fxn=accumulate)[0]
  if not bias_first:value=value+bias.reshape(1,1,1,oc)
  if residual is not None:value=value+residual
  if isinstance(activation,bytes):activation=activation.decode()
  if activation is None:return value
  return {'Relu':value.relu,'Sigmoid':value.sigmoid,'Tanh':value.tanh}[activation]()

root=Path(__file__).resolve().parents[2]; directory=root/'android/app/build/model-reference/trace-fused'
if '--complete' in sys.argv:directory=root/'android/build/trace-complete'
report={'diagnostic_only':True,'vehicle_tx_enabled':False,'backend':'METAL','reference_seed':42,'rtol':1e-3,'atol':1e-4,'scope':'host arithmetic experiments; original qualification gates unchanged','models':{}}
with Context(FLOAT16=0,IMAGE=0,BEAM=0):
  for name in ('dmonitoring_model','driving_supercombo'):
    model=onnx.load(directory/(name+'.onnx'))
    weights={v.name:numpy_helper.to_array(v) for v in model.graph.initializer}
    checks=[]
    if '--full' in sys.argv:
      runner=OnnxRunner(Tensor((directory/(name+'.onnx')).read_bytes(),device='PYTHON')).to('METAL')
      fused_ops(runner)
      if '--plain' not in sys.argv:runner.onnx_ops['NhwcFusedConv']=host_conv
      def nchw(x,w,b=None,residual=None,**opts):
        return host_conv(x.permute(0,2,3,1),w,b,None if residual is None else residual.permute(0,2,3,1),**opts).permute(0,3,1,2)
      if '--plain' not in sys.argv:runner.onnx_ops['FusedConv']=nchw
      with np.load(root/f'android/app/build/model-reference/{name}-inputs.npz') as values:
        inputs={k:Tensor(values[k],device='METAL') for k in values.files}
      started=time.monotonic();tensors=runner(inputs);Tensor.realize(*tensors.values())
      actual={k:v.numpy() for k,v in tensors.items()};elapsed=time.monotonic()-started
      with np.load(directory/(name+'-outputs.npz')) as expected:
        for key,value in actual.items():
          error=np.abs(value.astype(np.float64)-expected[key].astype(np.float64))
          allowed=np.isinf(value)&(value==expected[key]);finite=np.isfinite(error)|allowed
          failures=(~finite)|((~allowed)&(error>1e-4+1e-3*np.abs(expected[key])))
          entry={'output':key,'shape':list(value.shape),'exact':bool(np.array_equal(value,expected[key])),
                 'mismatched':int(np.count_nonzero(failures)),
                 'max_abs_error':float(error[np.isfinite(error)].max(initial=0))}
          checks.append(entry)
      nodes=json.loads((directory/'manifest.json').read_text())['models'][name]['nodes']
      by_output={v['output']:v for v in checks}
      difference=next(({**n,**by_output[n['output']]} for n in nodes if not by_output[n['output']]['exact']),None)
      divergence=next(({**n,**by_output[n['output']]} for n in nodes if by_output[n['output']]['mismatched']),None)
      report['models'][name]={'seconds':elapsed,'checks':checks,'first_difference':difference,'first_divergence':divergence}
      print(name,elapsed,'seconds','first_divergence',json.dumps(divergence),flush=True)
      continue
    with np.load(directory/(name+'-outputs.npz')) as values:
      for node in model.graph.node:
        if node.op_type not in ('Conv','FusedConv','NhwcFusedConv') or node.output[0] not in values or node.input[0] not in values:continue
        attrs={a.name:onnx.helper.get_attribute_value(a) for a in node.attribute}
        inputs=[Tensor(values[k] if k in values else weights[k],device='METAL') for k in node.input]
        nhwc=node.op_type=='NhwcFusedConv'
        if not nhwc:
          inputs[0]=inputs[0].permute(0,2,3,1)
          if len(inputs)>3:inputs[3]=inputs[3].permute(0,2,3,1)
        if '--bias-last' in sys.argv:attrs['bias_first']=False
        started=time.monotonic();actual=host_conv(*inputs,**attrs).numpy();elapsed=time.monotonic()-started
        expected=values[node.output[0]]
        if not nhwc:expected=expected.transpose(0,2,3,1)
        error=np.abs(actual.astype(np.float64)-expected)
        entry={'node':node.name,'shape':list(actual.shape),'seconds':elapsed,'exact':bool(np.array_equal(actual,expected)),
               'mismatched':int(np.count_nonzero(error>1e-4+1e-3*np.abs(expected))),'max_abs_error':float(error.max())}
        checks.append(entry);print(name,entry,flush=True)
        if len(checks)>=12:break
    report['models'][name]=checks
filename='ordered-convolution-full-prototype.json' if '--full' in sys.argv else 'ordered-convolution-prototype.json'
if '--complete' in sys.argv:filename='complete-trace-'+('plain' if '--plain' in sys.argv else 'ordered')+'-prototype.json'
if '--full' not in sys.argv and '--complete' in sys.argv:filename='complete-convolution-micro-'+('bias-last' if '--bias-last' in sys.argv else 'bias-first')+'.json'
(root/'android/reports/blocker-fixes'/filename).write_text(json.dumps(report,indent=2)+'\n')
