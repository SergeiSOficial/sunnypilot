import json
from pathlib import Path
import numpy as np
import onnx

root=Path(__file__).resolve().parents[2];directory=root/'android/build/trace-complete'
report={'scope':'diagnostic only: pinned MLAS logistic polynomial, sampled original intermediate inputs','models':{}}
def fma(a,b,c):return (a.astype(np.float64)*b+c).astype(np.float32)
def logistic(x):
  v=np.clip(x,-18.,18.);square=v*v
  p=fma(square,np.float32(4.37031012579801e-11),np.float32(1.15627324459942e-07))
  for c in (6.08574864600143e-05,8.51377133304701e-03,2.48287947061529e-01):p=fma(p,square,np.float32(c))
  p=p*v
  q=fma(square,np.float32(6.10247389755681e-13),np.float32(5.76102136993427e-09))
  for c in (6.29106785017040e-06,1.70198817374094e-03,1.16817656904453e-01,9.93151921023180e-01):q=fma(q,square,np.float32(c))
  return np.clip(p/q+np.float32(.5),0,1)
for name in ('dmonitoring_model','driving_supercombo'):
  model=onnx.load(directory/(name+'.onnx'));checks=[]
  with np.load(directory/(name+'-outputs.npz')) as values:
    for index,node in enumerate(model.graph.node):
      if node.op_type not in ('QuickGelu','Sigmoid') or node.input[0] not in values:continue
      x=values[node.input[0]].ravel();expected=values[node.output[0]].ravel()
      selection=np.random.default_rng(42).integers(0,len(x),min(4096,len(x)));x=x[selection];expected=expected[selection]
      alpha=next((onnx.helper.get_attribute_value(a) for a in node.attribute if a.name=='alpha'),1.)
      actual=logistic(x*np.float32(alpha))
      if node.op_type=='QuickGelu':actual=x*actual
      checks.append({'index':index,'node':node.name,'operator':node.op_type,'dtype':str(x.dtype),'samples':len(x),
                     'exact':int(np.count_nonzero(actual==expected)),
                     'max_abs_error':float(np.max(np.abs(actual.astype(np.float64)-expected))),
                     'mismatched':int(np.count_nonzero(~np.isclose(actual,expected,rtol=1e-3,atol=1e-4)))})
  report['models'][name]=checks
  print(name, 'nodes',len(checks), 'inexact', [v for v in checks if v['exact']!=v['samples']],flush=True)
(root/'android/reports/blocker-fixes/logistic-polynomial-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n')
