"""Diagnostic only: pinned MLAS float32 transcendental arithmetic on Metal."""
import sys
from pathlib import Path

from tinygrad import Tensor, UOp, dtypes
from tinygrad.uop.ops import KernelInfo, Ops


def scalar(expression, *values):
  if '/' in expression:
    expression = 'precise::divide({0}, {1})'
  values = tuple(value if isinstance(value, UOp) else UOp.const(value, dtypes.float32) for value in values)
  return UOp(Ops.CUSTOM, src=values, arg=(expression, dtypes.float32))


def mlas(x, kind):
  original = x.dtype
  x = Tensor.empty(*x.shape, device=x.device, dtype=dtypes.float32).realize().assign(x.float()).realize()

  def kernel(dest, source):
    index = UOp.range(dest.numel(), 0)
    v = source.flatten()[index].load()
    limit = 9. if kind == 'Tanh' else 18.
    v = v.maximum(-limit).minimum(limit)
    square = scalar('{0} * {0}', v)
    if kind == 'Tanh':
      numerator = (-2.76076847742355e-16, 2.00018790482477e-13, -8.60467152213735e-11,
                   5.12229709037114e-08, 1.48572235717979e-05, 6.37261928875436e-04, 4.89352455891786e-03)
      denominator = (1.19825839466702e-06, 1.18534705686654e-04, 2.26843463243900e-03, 4.89352518554385e-03)
    else:
      numerator = (4.37031012579801e-11, 1.15627324459942e-07, 6.08574864600143e-05,
                   8.51377133304701e-03, 2.48287947061529e-01)
      denominator = (6.10247389755681e-13, 5.76102136993427e-09, 6.29106785017040e-06,
                     1.70198817374094e-03, 1.16817656904453e-01, 9.93151921023180e-01)
    def polynomial(coefficients):
      value = UOp.const(coefficients[0], dtypes.float32)
      for coefficient in coefficients[1:]:
        value = scalar('fma({0}, {1}, {2})', value, square, coefficient)
      return value
    value = scalar('{0} / {1}', scalar('{0} * {1}', polynomial(numerator), v), polynomial(denominator))
    if kind != 'Tanh':
      value = scalar('{0} + 0.5f', value).maximum(0.).minimum(1.)
    return dest.flatten()[index].set(value, end=index).sink(arg=KernelInfo(name='mlas_' + kind, opts_to_apply=()))

  return Tensor.empty(*x.shape, device=x.device, dtype=dtypes.float32).custom_kernel(x, fxn=kernel)[0].cast(original)


def division(a, b):
  if a.dtype != dtypes.float32 or b.dtype != dtypes.float32:
    return a / b
  if b.numel() == 1:
    denominator = float(b.item())
    def constant_kernel(dest, left):
      index = UOp.range(dest.numel(), 0)
      value = scalar('{0} / {1}', left.flatten()[index].load(), denominator)
      return dest.flatten()[index].set(value, end=index).sink(arg=KernelInfo(name='ieee_div_constant', opts_to_apply=()))
    return Tensor.empty(*a.shape, device=a.device, dtype=a.dtype).custom_kernel(a.contiguous(), fxn=constant_kernel)[0]
  if a.shape != b.shape and a.numel() != 1 and b.numel() != 1:
    return a / b
  shape = b.shape if a.numel() == 1 else a.shape
  a, b = a.contiguous().realize(), b.contiguous().realize()
  def kernel(dest, left, right):
    index = UOp.range(dest.numel(), 0)
    value = scalar('{0} / {1}', left.flatten()[0 if a.numel() == 1 else index].load(),
                   right.flatten()[0 if b.numel() == 1 else index].load())
    return dest.flatten()[index].set(value, end=index).sink(arg=KernelInfo(name='ieee_div', opts_to_apply=()))
  return Tensor.empty(*shape, device=a.device, dtype=a.dtype).custom_kernel(a, b, fxn=kernel)[0]


def install(runner):
  runner.onnx_ops.update(Tanh=lambda x: mlas(x, 'Tanh'), Sigmoid=lambda x: mlas(x, 'Sigmoid'),
                         QuickGelu=lambda x, alpha=1.: x * mlas(x * alpha, 'Sigmoid'), Div=division)


if __name__ == '__main__':
  root = Path(__file__).resolve().parents[2]
  program = (root / 'android/build/prototype-host-conv.py').read_text()
  # Patch the archived runner only; no packaged/runtime model operator is modified.
  program = program.replace('      fused_ops(runner)', '      fused_ops(runner)\n      install(runner)')
  program = program.replace('        return host_conv(x.permute', "        opts['bias_first'] = False\n        return host_conv(x.permute")
  program = program.replace("runner.onnx_ops['FusedConv']=nchw", "runner.onnx_ops.update(FusedConv=nchw, Conv=nchw)")
  program = program.replace("'ordered')+'-prototype.json'", "'ordered-mlas-all')+'-prototype.json'")
  sys.argv = [sys.argv[0], '--full', '--complete', *sys.argv[1:]]
  exec(compile(program, str(root / 'android/build/prototype-host-conv.py'), 'exec'))
